﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WindowHeight = 25;
            Console.WindowWidth = 80;
            string selectedItem = GetRandomSantaItem();
            Console.WriteLine("       <단어 만들기 조작법>       ");
            Console.WriteLine("1. 화면에 나오는 단어를 확인한다. ");
            Console.WriteLine("2. 확인 후 게임창에서 떨어지는 자음,모음을 방향키로 잡는다.");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine(">>>>>     그럼 지금부터      <<<<<");
            Console.WriteLine("!!!!!!!단어 만들기 게임시작!!!!!!!");

            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("당신이 만들 단어는 " + "!'" + selectedItem + "'!" + " 입니다");

          
            PlayGame();
        }
        static string GetRandomSantaItem()
        {
            string[] santaItems = { "산타", "모자", "가방", "트리", "장갑" };
            Random a = new Random();

            int selectedIndex = a.Next(santaItems.Length);
            return santaItems[selectedIndex];


        }
        static void PlayGame()
        {
            Console.Clear();

            int consoleWidth = Console.WindowWidth;
            int consoleHeight = Console.WindowHeight;

            int playerPosition = consoleWidth / 2;
            char playerCharacter = 'ㅁ';

            int score = 0;

            Random random = new Random();
            while (true)
            {
                Console.Clear();

                char fallingCharacter = GetRandomCharacter();

                int fallingCharacterPosition = random.Next(consoleWidth);
                int fallingCharacterHeight = 0;


                Console.SetCursorPosition(fallingCharacterPosition, fallingCharacterHeight);
                Console.Write(fallingCharacter);


                Console.SetCursorPosition(playerPosition, consoleHeight - 24);
                Console.Write(playerCharacter);


                Console.SetCursorPosition(0, consoleHeight - 2);
                Console.Write($"Score: {score}");

                if (fallingCharacterHeight == consoleHeight - 1)
                {

                    score--;
                    if (score < 0)
                    {
                        Console.Clear();
                        Console.WriteLine("점수가 0 이하로 떨어졌습니다. 게임 오버!");
                        break;
                    }


                    fallingCharacterPosition = random.Next(consoleWidth);
                    fallingCharacterHeight = 0;
                }


                if (Console.KeyAvailable)
                {
                    ConsoleKeyInfo key = Console.ReadKey(true);
                    if (key.Key == ConsoleKey.LeftArrow && playerPosition > 0)
                    {
                        playerPosition--;
                    }
                    else if (key.Key == ConsoleKey.RightArrow && playerPosition < consoleWidth - 1)
                    {
                        playerPosition++;
                    }
                    else if (key.Key == ConsoleKey.DownArrow && fallingCharacterPosition == playerPosition && fallingCharacterHeight == consoleHeight - 1)
                    {

                        score++;


                        fallingCharacterPosition = random.Next(consoleWidth);
                        fallingCharacterHeight = 0;
                    }
                }


                fallingCharacterHeight++;


                Thread.Sleep(1000);
            }

            Console.WriteLine($"게임 종료. 최종 점수: {score}");
        }

        static char GetRandomCharacter()
        {
            char[] characters = { 'ㄱ', 'ㄴ', 'ㄷ', 'ㄹ', 'ㅁ', 'ㅂ', 'ㅅ', 'ㅇ', 'ㅈ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ', 'ㅏ', 'ㅑ', 'ㅓ', 'ㅕ', 'ㅗ', 'ㅛ', 'ㅜ', 'ㅠ', 'ㅡ', 'ㅣ' };
            Random random = new Random();
            int selectedIndex = random.Next(characters.Length);
            return characters[selectedIndex];
        }
    }
}
